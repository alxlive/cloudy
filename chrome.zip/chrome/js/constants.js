/* CONSTANTS */ 

// max attachment size in bytes
MAX_ATTACHMENT_SIZE=25*1024*1024
